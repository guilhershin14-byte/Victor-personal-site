
import React from 'react';
export default function App(){
 return (
  <div style={{textAlign:'center',padding:'40px'}}>
   <h1 style={{color:'red'}}>Victor Oliveira Personal</h1>
   <img src="https://i.postimg.cc/Wb7q9MXQ/Screenshot-20260503-121621-Instagram.jpg" width="300"/>
   <h2>Resultados dos alunos</h2>
   <img src="https://i.postimg.cc/85hz7SYh/Screenshot-20260503-121642-Instagram.jpg" width="300"/>
   <img src="https://i.postimg.cc/m2ZggKy1/Screenshot-20260503-121701-Instagram.jpg" width="300"/>
   <br/><br/>
   <a href="https://wa.me/5511942295298?text=Olá%20Victor">WhatsApp</a>
  </div>
 )
}
